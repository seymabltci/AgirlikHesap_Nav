package com.seyma.agirlikhesap_nav

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.database.getDoubleOrNull
import androidx.core.database.getIntOrNull
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import com.seyma.agirlikhesap_nav.databinding.ActivityHesapListesiBinding
import com.seyma.agirlikhesap_nav.databinding.RecyclerViewKayitBinding


class HesapListesiActivity : AppCompatActivity() {

    lateinit var binding: ActivityHesapListesiBinding
    lateinit var kayitListesi: ArrayList<Kayitlar>
    lateinit var KayitAdapter: KayitAdapter


    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)


        binding = ActivityHesapListesiBinding.inflate(layoutInflater)
        setContentView(binding.root)


        kayitListesi = ArrayList<Kayitlar>()

        KayitAdapter = KayitAdapter(this,kayitListesi)

        binding.RecyclerViewHesap.layoutManager = LinearLayoutManager(this)

        binding.RecyclerViewHesap.adapter = KayitAdapter

        binding.toolbar2.title = ("     Hesaplama Listesi")
        binding.toolbar2.setTitleTextColor(ContextCompat.getColor(this, R.color.white))



        if(kayitlardao(this).isTableEmpty()) {

            binding.btnTeklif.isVisible = false
        }
        else{
            binding.btnTeklif.isVisible = true
        }


        binding.btnBack.setOnClickListener{
            startActivity(Intent(this, MainActivity::class.java))
        }

        try {

            val database = this.openOrCreateDatabase("Agirlik", Context.MODE_PRIVATE, null)
            val cursor = database.rawQuery("SELECT * FROM kayitlar", null)
            val idIx = cursor.getColumnIndex("id")
            val malzemeIx = cursor.getColumnIndex("malzeme")
            val materyalIx = cursor.getColumnIndex("materyal")
            val birimAgirlikIx = cursor.getColumnIndex("birimAgirlik")
            val toplamAgirlikIx = cursor.getColumnIndex("toplamAgirlik")
            val adetIx = cursor.getColumnIndex("adet")
            val uzunlukIx = cursor.getColumnIndex("uzunluk")
            val etKalinligiIx = cursor.getColumnIndex("etKalinligi")
            val capIx = cursor.getColumnIndex("cap")
            val enIx = cursor.getColumnIndex("en")
            val yukseklikIx = cursor.getColumnIndex("yukseklik")


            while (cursor.moveToNext()) {
                val id = cursor.getInt(idIx)
                val malzeme = cursor.getString(malzemeIx)
                val materyal = cursor.getString(materyalIx)
                val birimAgirlik = cursor.getDouble(birimAgirlikIx)
                val toplamAgirlik = cursor.getDoubleOrNull(toplamAgirlikIx)
                val adet = cursor.getIntOrNull(adetIx)
                val uzunluk = cursor.getDouble(uzunlukIx)
                val etKalinligi = cursor.getDoubleOrNull(etKalinligiIx)
                val cap = cursor.getDoubleOrNull(capIx)
                val en = cursor.getDoubleOrNull(enIx)
                val yukseklik = cursor.getDoubleOrNull(yukseklikIx)


                val kayit = Kayitlar(id, malzeme, materyal,birimAgirlik, toplamAgirlik, adet, uzunluk, etKalinligi, cap,en, yukseklik )
                kayitListesi.add(kayit)

            }
            KayitAdapter.notifyDataSetChanged() //veri seti değişti db haber et



            cursor.close()
        }



        catch (e: Exception){
            e.printStackTrace()
        }

        binding.btnTeklif.setOnClickListener {

            val sonucHoler = KayitAdapter.KayitlarHoler(
                RecyclerViewKayitBinding.inflate(layoutInflater)
            )
            Log.e("adet", kayitListesi.size.toString())
            for (i in 0 until kayitListesi.size ) {
                val kayit = kayitListesi[i]
                sonucHoler.sendMail (
                    kayit.malzeme,
                    kayit.materyal,
                    kayit.birimAgirlik.toString().toDouble(),
                    kayit.toplamAgirlik.toString().toDouble(),
                    kayit.yukseklik.toString().toDouble(),
                    kayit.uzunluk.toString().toDouble(),
                    kayit.en.toString().toDouble(),
                    kayit.cap.toString().toDouble(),
                    kayit.adet.toString().toInt(),
                    kayit.etKalinligi.toString().toDouble()
                )
            }
        }
    }
}

