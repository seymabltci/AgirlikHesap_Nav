package com.seyma.agirlikhesap_nav


import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.seyma.agirlikhesap_nav.databinding.RecyclerViewKayitBinding
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols


class KayitAdapter (val mcontext: Context, val kayitList : ArrayList<Kayitlar>)
    : RecyclerView.Adapter<KayitAdapter.KayitlarHoler>() {

   inner class KayitlarHoler(val binding: RecyclerViewKayitBinding) : RecyclerView.ViewHolder(binding.root){
        fun sendMail(malzeme: String, materyal: String, BrAgirlik: Double,TpAgirlik: Double,
                     yukseklik: Double, uzunluk: Double,en: Double,cap: Double,
                     adet: Int, etKalinligi: Double)
                      {

            val alici = "seymabaltaci19@gmail.com"
            val konu = "Teklif Al"

                          val mesaj = mutableListOf<String>()

                          mesaj.add(" ")
                          mesaj.add("Malzeme: $malzeme       Materyal: $materyal")

           when (malzeme) {
           "Mil" -> mesaj.add("Ölçüler: ${cap.toInt()}")
           "Boru" -> mesaj.add("Ölçüler: ${cap.toInt()} X $etKalinligi")
           "Kare Demir" -> mesaj.add("Ölçüler: ${en.toInt()}")
           "Silme/Lama" -> mesaj.add("Ölçüler: ${en.toInt()} X ${yukseklik.toInt()}")
           "Profil" -> mesaj.add("Ölçüler: ${en.toInt()} X ${yukseklik.toInt()} X $etKalinligi")
           "Köşebent" -> mesaj.add("Ölçüler: ${en.toInt()} X ${yukseklik.toInt()} X $etKalinligi")
           }

                          val df = DecimalFormat("#.###")
                          val symbols = DecimalFormatSymbols().apply {
                              decimalSeparator = ',' // Virgülü ayarla
                          }
                          df.decimalFormatSymbols = symbols
                          df.roundingMode = RoundingMode.CEILING
                          val formattedValue = df.format(BrAgirlik)
                          val formattedValue2 = df.format(TpAgirlik)

           mesaj.add("Uzunluk: ${uzunluk.toInt()}")
           mesaj.add("Birim Ağırlığı: $formattedValue")

           if (adet!= 0 && TpAgirlik!= 0.0) {
             mesaj.add("Toplam Ağırlık($adet adet): $formattedValue2")
           }

           mesaj.add(" ")

            val mesajDizisi = mesaj.joinToString("\n")
            Log.e("adet44", mesajDizisi)


            val mIntent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:")
                putExtra(Intent.EXTRA_EMAIL, arrayOf(alici))
                putExtra(Intent.EXTRA_SUBJECT, konu)
                putExtra(Intent.EXTRA_TEXT, mesajDizisi)
            }

            try {
                mcontext.startActivity(Intent.createChooser(mIntent, "Send Mail"))
            } catch (e: Exception) {
                Toast.makeText(mcontext, e.message, Toast.LENGTH_LONG).show()
            }
        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): KayitlarHoler {
        val binding = RecyclerViewKayitBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false)


        return KayitlarHoler(binding)
    }

    override fun getItemCount(): Int {
       return kayitList.size
    }

    override fun onBindViewHolder(holder: KayitlarHoler, position: Int) {

        val kayit = kayitList.get(position)

        val doubleFormat = DecimalFormat("#.###")
        doubleFormat.roundingMode = RoundingMode.CEILING
        var formatAgirlik = doubleFormat.format(kayit.birimAgirlik)
        var formatToplam = doubleFormat.format(kayit.toplamAgirlik)



        holder.binding.tvMalzeme.text = kayit.malzeme
        holder.binding.tvMateryal.text = kayit.materyal
        holder.binding.tvEn.text = kayit.en.toString()
        holder.binding.tvCap.text = kayit.cap.toString()
        holder.binding.tvYukseklik.text = kayit.yukseklik.toString()
        holder.binding.tvEtKalinligi.text = kayit.etKalinligi.toString()
        holder.binding.tvUzunluk.text = kayit.uzunluk.toString()
        holder.binding.tvBrAgirlik.text = formatAgirlik.toString()
        holder.binding.tvTpAgirlik.text = formatToplam.toString()
        holder.binding.tvTpAdet.text = kayit.adet.toString()

        if (kayit.adet == 0) {

            holder.binding.tvTpAdet.isVisible = false
            holder.binding.tvAdet.isVisible = false
            holder.binding.tvTp.isVisible = false
            holder.binding.tvTpAgirlik.isVisible = false
            holder.binding.tvTpKg.isVisible = false
            holder.binding.tvEn.visibility = View.GONE
            holder.binding.tvYukseklik.visibility = View.GONE
        }

        if (kayit.malzeme == "Boru") {
            holder.binding.tvEn.visibility = View.GONE
            holder.binding.tvYukseklik.visibility = View.GONE
            holder.binding.capToEn.isVisible = false
            holder.binding.enToYuk.isVisible = false

        }
        if (kayit.malzeme == "Kare Demir") {
            holder.binding.tvCap.visibility = View.GONE
            holder.binding.tvEtKalinligi.visibility = View.GONE
            holder.binding.tvYukseklik.visibility = View.GONE
            holder.binding.capToEn.isVisible = false
            holder.binding.enToYuk.isVisible = false
            holder.binding.yukToEtk.isVisible = false
        }
        if (kayit.malzeme == "Mil") {
            holder.binding.tvEn.visibility = View.GONE
            holder.binding.tvYukseklik.visibility = View.GONE
            holder.binding.tvEtKalinligi.visibility = View.GONE
            holder.binding.capToEn.isVisible = false
            holder.binding.enToYuk.isVisible = false
            holder.binding.yukToEtk.isVisible = false
        }
        if (kayit.malzeme == "Profil") {
            holder.binding.tvCap.visibility = View.GONE
            holder.binding.capToEn.isVisible = false
        }
        if (kayit.malzeme == "Köşebent") {
            holder.binding.tvCap.visibility = View.GONE
            holder.binding.capToEn.isVisible = false
        }
        if (kayit.malzeme == "Silme/Lama") {
            holder.binding.tvCap.visibility = View.GONE
            holder.binding.tvEtKalinligi.visibility = View.GONE
            holder.binding.capToEn.isVisible = false
            holder.binding.yukToEtk.isVisible = false

        }




        holder.binding.delete.setOnClickListener {

            kayitlardao(mcontext).sil(kayitList.get(position).id)
            kayitList.remove(kayitList[position])
            notifyDataSetChanged()


        }

    }
}



