package com.seyma.agirlikhesap_nav


import android.content.Context

class kayitlardao (mcontext: Context) {

    val database = mcontext.openOrCreateDatabase("Agirlik", Context.MODE_PRIVATE, null)
    fun sil(id: Int) {
        database.execSQL("CREATE TABLE IF NOT EXISTS kayitlar (id INTEGER PRIMARY KEY AUTOINCREMENT,malzeme VARCHAR,materyal VARCHAR, birimAgirlik DOUBLE, toplamAgirlik DOUBLE, adet INT, uzunluk DOUBLE, etKalinligi DOUBLE, cap VARCHAR, en DOUBLE, yukseklik DOUBLE )")

        val sqlDelete = "DELETE FROM kayitlar WHERE id = ?"
        val statement = database.compileStatement(sqlDelete)
        statement.bindLong(1, id.toLong())
        statement.execute() // Sorguyu çalıştır

        // Gerekli temizlik işlemlerini yap
        statement.close()
        database.close()
    }
    fun isTableEmpty(): Boolean {
        val countQuery = "SELECT COUNT(*) FROM kayitlar"
        val cursor = database.rawQuery(countQuery, null)
        cursor.moveToFirst()
        val count = cursor.getInt(0)
        cursor.close()
        return count == 0
    }



    fun ekle(
        malzeme: String,
        materyal: String,
        birimAgirlik: Double,
        toplamAgirlik: Double,
        adet: Int,
        uzunluk: Double,
        etKalinligi: Double,
        cap: Double,
        en: Double,
        yukseklik: Double
    ) {

        try {

            database.execSQL("CREATE TABLE IF NOT EXISTS kayitlar (id INTEGER PRIMARY KEY AUTOINCREMENT,malzeme VARCHAR,materyal VARCHAR, birimAgirlik DOUBLE, toplamAgirlik DOUBLE, adet INT, uzunluk DOUBLE, etKalinligi DOUBLE, cap VARCHAR, en DOUBLE, yukseklik DOUBLE )")

            val sqlInsert =
                "INSERT INTO kayitlar (malzeme,materyal, birimAgirlik, toplamAgirlik, adet, uzunluk, etKalinligi, cap, en, yukseklik) VALUES (?,?,?,?,?,?,?,?,?,?)"
            val statement = database.compileStatement(sqlInsert)
            statement.bindString(1, malzeme)
            statement.bindString(2, materyal)
            statement.bindDouble(3, birimAgirlik)
            statement.bindDouble(4, toplamAgirlik)
            statement.bindLong(5, adet.toLong())
            statement.bindDouble(6, uzunluk)
            statement.bindDouble(7, etKalinligi)
            statement.bindDouble(8, cap)
            statement.bindDouble(9, en)
            statement.bindDouble(10, yukseklik)
            statement.execute()
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }
}


