package com.seyma.agirlikhesap_nav

import java.io.Serializable

class Malzemeler (val malzemeName : String, val malzemeResim : Int) : Serializable { //serileştirilebilir bir sınıf oldugunu gösterir



}