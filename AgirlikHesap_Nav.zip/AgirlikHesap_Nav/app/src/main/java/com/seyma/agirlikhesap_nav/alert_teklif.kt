package com.seyma.agirlikhesap_nav

import android.content.Context
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

fun teklif ( mcontext : Context) {
       val tasarim = LayoutInflater.from(mcontext).inflate(R.layout.alert_tasarim, null)
       val editTextPhone = tasarim.findViewById(R.id.editTextPhone) as EditText
       val editTextName = tasarim.findViewById(R.id.editTextName) as EditText
       val ad = AlertDialog.Builder(mcontext)
       ad.setTitle("İletişim Bilgilerinizi Giriniz.")
       ad.setIcon(R.drawable.contact)
       ad.setView(tasarim)

       ad.setPositiveButton("Gönder") { dialogInterface, i ->
           Toast.makeText(
               mcontext,
               "Bilgileriniz gönderildi.",
               Toast.LENGTH_SHORT
           ).show()
           //snackbar da kullanabilirsin bölüm14. 197.ders
       }

       ad.setNegativeButton("İptal") { dialogInterface, i ->
           Toast.makeText(mcontext, "İptal edildi", Toast.LENGTH_SHORT).show()
       }
           ad.show()
   }